# Projet Thymio Glolfeur
*Le projet finale  de module Robot Mobile 2022/2023.*
---

# Les membres:
1. [houchi branis](https://framagit.org/houchi192)
2. [Granvisir-clerc Louis](https://framagit.org/lgvc)


    
# Les étapes du projet:


1. *Calibration du Robot*
    - Pour qu'il aille tout droit
    - Pour qu'il se retourne
2. *Partie Code*
    - Lecture des variation du noir
    - Calcule vitesse Robot
    - Calcule du code barre
    - Lecture de Code barre.
    - Afficher les couleurs correspondante au code barre
    - Gestion de la balle.
    - Gestion de l'angle.

3. *Realisation du poster*


# 2022_gareth_bale
[![](https://mermaid.ink/img/pako:eNp1kk1vwyAMhv8K8jmpgCRk5Tat2k6VJu20KRcaaIaUQEXItK7qf5_zsW6aWh-Q9ZrnBWNOUHttQEKjXIyVIxjRxtaQe_I0SmRjVRNUN5e0iubRh05FQl4x0u023WzmWm_qaL0jD2g4K7Vq7S6oSf0NqVhCOOU8ZTTlNCGs0IvDYD8s0Ya0tnHmOsLSHAm2EC2eOQRDxibITgVMte2jcvVNnBXI0wv_H1euac01jv_lpvWn4WffRxOWloOZ-0XDw6TfugfHnGUXP0igM_iwVuMwTqNaQXw3nalAYqrNXg1trKByZ9yqhuhfjq4GGcNgEhgO42SWUYHcq7ZH9aAcyBN8gsTbrwTPS1FmNMuFKNdlAkeQWZavaCbWXHCxLjLGi3MCX96jB1sVQrCCCVYKSu9oWU6Gb1NxPtVoG33Yzh9o-kfnb2bPpT8?type=png)](https://mermaid.live/edit#pako:eNp1kk1vwyAMhv8K8jmpgCRk5Tat2k6VJu20KRcaaIaUQEXItK7qf5_zsW6aWh-Q9ZrnBWNOUHttQEKjXIyVIxjRxtaQe_I0SmRjVRNUN5e0iubRh05FQl4x0u023WzmWm_qaL0jD2g4K7Vq7S6oSf0NqVhCOOU8ZTTlNCGs0IvDYD8s0Ya0tnHmOsLSHAm2EC2eOQRDxibITgVMte2jcvVNnBXI0wv_H1euac01jv_lpvWn4WffRxOWloOZ-0XDw6TfugfHnGUXP0igM_iwVuMwTqNaQXw3nalAYqrNXg1trKByZ9yqhuhfjq4GGcNgEhgO42SWUYHcq7ZH9aAcyBN8gsTbrwTPS1FmNMuFKNdlAkeQWZavaCbWXHCxLjLGi3MCX96jB1sVQrCCCVYKSu9oWU6Gb1NxPtVoG33Yzh9o-kfnb2bPpT8)
